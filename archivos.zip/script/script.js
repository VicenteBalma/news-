

// PAGE LOADER //

document.addEventListener("DOMContentLoaded", function () {
    // Mostrar el loader durante 1 segundo (1000 milisegundos)
    setTimeout(function () {
      document.querySelector('.loader-container').style.display = 'none'; // Ocultar el loader-container
      document.querySelector('.content').style.display = 'block'; // Mostrar el contenido de la página
    }, 900); // Cambia este valor al tiempo que desees que el loader sea visible
  });



  document.addEventListener("DOMContentLoaded", function () {
    // Mostrar el contenido después de 2,3 segundos
    setTimeout(function () {
      const content = document.querySelector('.content');
      content.classList.add('content-show'); // Agregar la clase para mostrar el contenido gradualmente
    }, 1300); // Cambia este valor al tiempo que desees que el loader sea visible
  });



  // NAV BAR //
